package UnitTest;

import Models.*;
import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;

public class InventoryTest {

    private Inventory inventory;
    private Item item;

    @BeforeEach
    void setUp() {
        inventory = new Inventory();
        item = new Item("Dell Inspiron 14", "Laptop",500.00,650.00,6);
    }

    @Test
    void testAddItem() {
        inventory.addItem(item);
        assertEquals(1, inventory.getItems().size(),
                "Item should be added to inventory");
    }

    @Test
    void testGetItemByName_ExistingItem() {
        inventory.addItem(item);
        Item found = inventory.findItemByName("Laptop");
        assertNotNull(found);
        assertEquals("Laptop", found.getName());
    }

    @Test
    void testGetItemByName_NonExistingItem() {
        Item found = inventory.findItemByName("Phone");
        assertNull(found, "Should return null if item does not exist");
    }

    @Test
    void testRemoveItem() {
        inventory.addItem(item);
        inventory.removeItem("Laptop");
        assertEquals(0, inventory.getItems().size());
    }
}
