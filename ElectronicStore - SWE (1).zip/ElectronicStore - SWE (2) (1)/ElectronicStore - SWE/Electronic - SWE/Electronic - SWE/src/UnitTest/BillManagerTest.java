package UnitTest;

import Models.BillManager;
import Models.Bill;
import Models.BillItem;
import Models.Item;

import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;

public class BillManagerTest {

    private BillManager billManager;
    private Bill bill;

    @BeforeEach
    void setUp() {
        billManager = new BillManager();
        bill = new Bill(1);
    }

    @Test
    void testCalculateTotalSingleItem() {
        Item item = new Item("Apple MacBook Air M1","Laptop",850.00,1050.00,2);
        bill.addItem(item, 2);

        double total = bill.getTotalAmount();
        assertEquals(2100.0, total);
    }

    @Test
    void testCalculateTotalMultipleItems() {
        Item item1 = new Item("Logitech Wireless Mouse", "Accessories", 12.00, 25.00, 2);
        Item item2 = new Item("HP USB Keyboard", "Accessories", 8.00, 18.00, 4);

        bill.addItem(item1, 2); 
        bill.addItem(item2, 1);

        double total = bill.getTotalAmount();
        assertEquals(68.0, total);
    }

    @Test
    void testCalculateTotalEmptyBill() {
        double total = bill.getTotalAmount();
        assertEquals(0.0, total);
    } 
}
