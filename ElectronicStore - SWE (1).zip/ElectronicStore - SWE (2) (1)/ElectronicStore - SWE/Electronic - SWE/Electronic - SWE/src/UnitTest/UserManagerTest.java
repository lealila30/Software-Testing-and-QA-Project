package UnitTest;

import Controllers.LoginController;
import Models.User;
import Models.UserManager;
import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;

public class UserManagerTest {

    private UserManager userManager;
    private LoginController loginAuthenticate;

    @BeforeEach
    void setUp() {
        userManager = new UserManager();
        loginAuthenticate = new LoginController(userManager);
    }

    @Test
    void testAddUser() {
        User user = new User("admin", "admin123", "Admin");
        userManager.addUser(user);

        User found = userManager.findUserByUsername("admin");
        assertNotNull(found);
    }

    @Test
    void testAuthenticateValidUser() {
        User user = new User("cashier", "cashier123", "Cashier");
        userManager.addUser(user);

        boolean result = loginAuthenticate.authenticateUser("cashier", "cashier123");
        assertTrue(result);
    }

    @Test
    void testAuthenticateInvalidPassword() {
        User user = new User("cashier", "pass", "Cashier");
        userManager.addUser(user);

        boolean result = loginAuthenticate.authenticateUser("cashier", "wrong");
        assertFalse(result);
    }
/*
    @Test
    void testAuthenticateUserNotFound() {
        boolean result = userManager.authenticate("unknown", "1234");
        assertFalse(result);
    } */
}

