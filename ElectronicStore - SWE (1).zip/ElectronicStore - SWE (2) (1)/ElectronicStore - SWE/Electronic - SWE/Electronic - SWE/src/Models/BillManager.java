package Models;

import java.io.*;
import java.nio.file.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

public class BillManager {

    private List<Bill> bills;

    public BillManager() {
        this.bills = new ArrayList<>();
        loadBillsFromFiles();   // 🔥 KY ESHTE FIX-I
    }

    public void addBill(Bill bill) {
        bills.add(bill);
    }

    public List<Bill> getBills() {
        return bills;
    }

    public List<Bill> getBillsWithinDateRange(LocalDate startDate, LocalDate endDate) {
        return bills.stream()
                .filter(bill -> {
                    LocalDate billDate = bill.getBillDate().toLocalDate();
                    return !billDate.isBefore(startDate) &&
                            !billDate.isAfter(endDate);
                })
                .collect(Collectors.toList());
    }

    public void saveBillToFile(Bill bill) {
        try {
            Files.createDirectories(Paths.get("bills"));
            String filename = "bills/Bill" + bill.getBillNumber() + ".txt";

            try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename))) {
                writer.write(bill.toString());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /* ================= LOAD FROM FILES ================= */

    private void loadBillsFromFiles() {
        Path billsDir = Paths.get("bills");

        if (!Files.exists(billsDir)) return;

        try {
            Files.list(billsDir)
                    .filter(path -> path.toString().endsWith(".txt"))
                    .forEach(this::parseBillFile);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void parseBillFile(Path path) {
        try {
            List<String> lines = Files.readAllLines(path);

            int billNumber = Integer.parseInt(
                    lines.get(0).replace("Bill Number: ", "").trim()
            );

            LocalDateTime billDate = LocalDateTime.parse(
                    lines.get(1).replace("Date: ", "").trim()
            );

            // ✅ IMPORTANT: use the correct constructor
            Bill bill = new Bill(billNumber, billDate);

            for (int i = 3; i < lines.size(); i++) {
                String line = lines.get(i);

                if (line.startsWith("Total Amount")) break;

                String name = line.substring(0, line.indexOf("(")).trim();

                String qtyPart = line.substring(
                        line.indexOf("Qty:") + 4,
                        line.indexOf(",")
                ).trim();
                int qty = Integer.parseInt(qtyPart);

                String pricePart = line.substring(
                        line.indexOf("$") + 1,
                        line.indexOf(")")
                ).trim();
                double price = Double.parseDouble(pricePart);

                bill.getBillItems().add(
                        new BillItem(name, price, qty)
                );
            }

            bills.add(bill);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
