package Models;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class Inventory {
    private List<Item> items;
    private String filename = "Electronic - SWE/data/inventory.txt";


    public Inventory() {
        this.items = new ArrayList<>();
        loadInventory();
    }

    //adds a new item to the inventory
    public void addItem(Item item) {
        items.add(item);
    }

    //gets the list of all items in the inventory
    public List<Item> getItems() {
        return items;
    }

    //finds an item by its name
    public Item findItemByName(String name) {
        return items.stream()
                .filter(item -> item.getName().equalsIgnoreCase(name))
                .findFirst()
                .orElse(null);
    }

    //save the inventory to a file
    public void saveInventory() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename))) {
            for (Item item : items) {
                writer.write(String.format("%s,%s,%.2f,%.2f,%d",
                        item.getName(),
                        item.getCategory(),
                        item.getPurchasePrice(),
                        item.getSellingPrice(),
                        item.getStockLevel()));
                writer.newLine();
            }
        } catch (IOException e) {
            System.err.println("Error saving inventory: " + e.getMessage());
        }
    }

    //loads the inventory from a file
    public void loadInventory() {
        items.clear(); //clears the current list before loading new data
        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 5) {
                    String name = parts[0];
                    String category = parts[1];
                    double purchasePrice = Double.parseDouble(parts[2]);
                    double sellingPrice = Double.parseDouble(parts[3]);
                    int stockLevel = Integer.parseInt(parts[4]);
                    items.add(new Item(name, category, purchasePrice, sellingPrice, stockLevel));
                }
            }
        } catch (IOException e) {
            System.err.println("Error loading inventory: " + e.getMessage());
        }
    }

    //updates the stock level of an existing item
    public boolean updateStockLevel(String name, int newStockLevel) {
        Item item = findItemByName(name);
        if (item != null) {
            item.setStockLevel(newStockLevel);
            return true;
        }
        return false;
    }

    //removes an item from the inventory
    public boolean removeItem(String name) {
        return items.removeIf(item -> item.getName().equalsIgnoreCase(name));
    }

    //gets a list of items with stock levels below or equal to a given threshold
    public List<Item> getLowStockItems(int threshold) {
        List<Item> lowStockItems = new ArrayList<>();
        for (Item item : items) {
            if (item.getStockLevel() <= threshold) {
                lowStockItems.add(item);
            }
        }
        return lowStockItems;
    }

    //adds a new category to the inventory 
    public void addNewItemCategory(String categoryName) {
        Item newCategoryItem = new Item("New " + categoryName + " Item", categoryName, 0.0, 0.0, 0);
        addItem(newCategoryItem);
        saveInventory();
    }
}
