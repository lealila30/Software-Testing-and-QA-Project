package Controllers;

import Models.Item;
import Models.User;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class DataPersistence {

    public static void saveUsers(String filename, List<User> users) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename))) {
            for (User user : users) {
                writer.write(user.getUsername() + "," + user.getPassword() + "," + user.getRole());
                writer.newLine();
            }
        } catch (IOException e) {
            System.err.println("Error saving users: " + e.getMessage());
        }
    }

    public static List<User> loadUsers(String filename) {
        List<User> users = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(",");
                users.add(new User(
                        data[0].trim(),
                        data[1].trim(),
                        data[2].trim()
                ));
            }
        } catch (IOException e) {
            System.err.println("Error loading users: " + e.getMessage());
        }
        return users;
    }

    public static void saveItems(String filename, List<Item> items) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename))) {
            for (Item item : items) {
                writer.write(item.getName() + "," + item.getCategory() + "," +
                        item.getPurchasePrice() + "," + item.getSellingPrice() + "," + item.getStockLevel());
                writer.newLine();
            }
        } catch (IOException e) {
            System.err.println("Error saving items: " + e.getMessage());
        }
    }

    public static List<Item> loadItems(String filename) {
        List<Item> items = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(",");
                if (data.length == 5) { //ensures there are exactly 5 fields for each item
                    String name = data[0];
                    String category = data[1];
                    double purchasePrice = Double.parseDouble(data[2]);
                    double sellingPrice = Double.parseDouble(data[3]);
                    int stockLevel = Integer.parseInt(data[4]);
                    
                    //creates a new Item object with the correct order of parameters
                    items.add(new Item(name, category, purchasePrice, sellingPrice, stockLevel));
                }
            }
        } catch (IOException e) {
            System.err.println("Error loading items: " + e.getMessage());
        }
        return items;
    }
}
