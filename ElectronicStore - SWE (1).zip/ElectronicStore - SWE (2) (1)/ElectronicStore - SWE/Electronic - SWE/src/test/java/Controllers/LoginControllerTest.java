package Controllers;

import Models.User;
import Models.UserManager;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class LoginControllerTest {

    private UserManager userManager;
    private LoginController loginController;

    @BeforeEach
    void setUp() {
        userManager = new UserManager();
        userManager.getUsers().clear(); // avoid file dependency if it loads
        userManager.addUser(new User("testUser", "pass123", "Manager"));

        loginController = new LoginController(userManager);
    }

    // -------- ECT --------

    @Test
    void ect_validUsernameAndPassword_returnsTrue() {
        assertTrue(loginController.authenticateUser("testUser", "pass123"));
    }

    @Test
    void ect_validUsername_wrongPassword_returnsFalse() {
        assertFalse(loginController.authenticateUser("testUser", "wrong"));
    }

    @Test
    void ect_wrongUsername_returnsFalse() {
        assertFalse(loginController.authenticateUser("wrongUser", "pass123"));
    }

    // -------- BVT style tests (edge-like inputs) --------

    @Test
    void bvt_emptyUsername_returnsFalse() {
        assertFalse(loginController.authenticateUser("", "pass123"));
    }

    @Test
    void bvt_emptyPassword_returnsFalse() {
        assertFalse(loginController.authenticateUser("testUser", ""));
    }

    @Test
    void bvt_bothEmpty_returnsFalse() {
        assertFalse(loginController.authenticateUser("", ""));
    }
}
