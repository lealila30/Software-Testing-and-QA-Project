package integration;

import Models.Inventory;
import Models.Item;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class InventoryIntegrationTest {

    @Test
    void inventoryAndItem_integrationWorksCorrectly() {
        Inventory inv = new Inventory();
        inv.getItems().clear();

        Item item = new Item("TV", "Electronics", 400, 600, 5);
        inv.addItem(item);

        inv.updateStockLevel("TV", 10);

        assertEquals(10, inv.findItemByName("TV").getStockLevel());
    }
}
