package integration;
import Models.*;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class SystemTest {

    @Test
    void fullSystemScenario_billWithinDateRange() {
        BillManager billManager = new BillManager();
        billManager.getBills().clear();

        Bill bill = new Bill(1, LocalDateTime.now());
        billManager.addBill(bill);

        List<Bill> result = billManager.getBillsWithinDateRange(
                LocalDate.now().minusDays(1),
                LocalDate.now().plusDays(1)
        );

        assertEquals(1, result.size());
    }
}
