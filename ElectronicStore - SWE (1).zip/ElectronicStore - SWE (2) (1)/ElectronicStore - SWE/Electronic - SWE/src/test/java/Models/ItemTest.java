package Models;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ItemTest {

	@Test
	void ect_negativePrice_defectFound() {
	    Item item = new Item("Phone", "Electronics", 100, 200, 5);
	    item.setSellingPrice(-5);

	    // Current behavior: negative price is accepted (this is a defect)
	    assertEquals(-5, item.getSellingPrice(),
	            "Defect: negative selling price is accepted but should be rejected.");
	}

    @Test
    void ect_zeroPrice() {
        Item item = new Item("Phone", "Electronics", 100, 200, 5);
        item.setSellingPrice(0);
        assertEquals(0, item.getSellingPrice());
    }

    @Test
    void ect_normalPrice() {
        Item item = new Item("Phone", "Electronics", 100, 200, 5);
        item.setSellingPrice(250);
        assertEquals(250, item.getSellingPrice());
    }

    @Test
    void ect_highPrice() {
        Item item = new Item("Phone", "Electronics", 100, 200, 5);
        item.setSellingPrice(1500);
        assertEquals(1500, item.getSellingPrice());
    }
}
