package Models;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class BillManagerTest {

    private BillManager billManager;

    @BeforeEach
    void setUp() {
        billManager = new BillManager();
        billManager.getBills().clear(); // ignore any real bills loaded from folder
    }

    private Bill billAt(LocalDateTime date, int number) {
        return new Bill(number, date);
    }

    @Test
    void mcdc_TT_billInsideRange_included() {
        Bill b = billAt(LocalDateTime.of(2026, 1, 10, 10, 0), 1);
        billManager.addBill(b);

        List<Bill> result = billManager.getBillsWithinDateRange(
                LocalDate.of(2026, 1, 1),
                LocalDate.of(2026, 1, 31)
        );

        assertEquals(1, result.size());
        assertTrue(result.contains(b));
    }

    @Test
    void mcdc_FT_billBeforeStart_excluded() {
        Bill b = billAt(LocalDateTime.of(2026, 1, 10, 10, 0), 2);
        billManager.addBill(b);

        List<Bill> result = billManager.getBillsWithinDateRange(
                LocalDate.of(2026, 1, 15), // makes C1 false
                LocalDate.of(2026, 1, 31)  // keeps C2 true
        );

        assertTrue(result.isEmpty());
    }

    @Test
    void mcdc_TF_billAfterEnd_excluded() {
        Bill b = billAt(LocalDateTime.of(2026, 1, 10, 10, 0), 3);
        billManager.addBill(b);

        List<Bill> result = billManager.getBillsWithinDateRange(
                LocalDate.of(2026, 1, 1), // keeps C1 true
                LocalDate.of(2026, 1, 5)  // makes C2 false
        );

        assertTrue(result.isEmpty());
    }
}
