package Models;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class InventoryTest {

    private Inventory inv;

    @BeforeEach
    void setUp() {
        inv = new Inventory();
        inv.getItems().clear(); // avoid depending on inventory.txt
        inv.addItem(new Item("Laptop", "Electronics", 500.0, 700.0, 10));
    }

    @Test
    void updateStockLevel_itemExists_returnsTrue() {
        assertTrue(inv.updateStockLevel("Laptop", 20));
        assertEquals(20, inv.findItemByName("Laptop").getStockLevel());
    }

    @Test
    void updateStockLevel_itemNotFound_returnsFalse() {
        assertFalse(inv.updateStockLevel("DoesNotExist", 5));
    }

    // ---- BOUNDARY VALUE TESTING for newStockLevel ----
    // Assumption (current implementation): any int is accepted (even negative),
    // because updateStockLevel does not validate range.

    @Test
    void bvt_updateStockLevel_belowMin_minus1() {
        assertTrue(inv.updateStockLevel("Laptop", -1));
        assertEquals(-1, inv.findItemByName("Laptop").getStockLevel());
    }

    @Test
    void bvt_updateStockLevel_min_0() {
        assertTrue(inv.updateStockLevel("Laptop", 0));
        assertEquals(0, inv.findItemByName("Laptop").getStockLevel());
    }

    @Test
    void bvt_updateStockLevel_justAboveMin_1() {
        assertTrue(inv.updateStockLevel("Laptop", 1));
        assertEquals(1, inv.findItemByName("Laptop").getStockLevel());
    }

    @Test
    void bvt_updateStockLevel_largeValue_999() {
        assertTrue(inv.updateStockLevel("Laptop", 999));
        assertEquals(999, inv.findItemByName("Laptop").getStockLevel());
    }

    @Test
    void removeItem_existingItem_removedSuccessfully() {
        assertTrue(inv.removeItem("Laptop"));
        assertNull(inv.findItemByName("Laptop"));
    }
}
