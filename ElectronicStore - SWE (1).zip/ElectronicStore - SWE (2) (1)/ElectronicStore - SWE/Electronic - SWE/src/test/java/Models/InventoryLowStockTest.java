package Models;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class InventoryLowStockTest {

    private Inventory inv;

    @BeforeEach
    void setUp() {
        inv = new Inventory();
        inv.getItems().clear(); // avoid file dependency

        inv.addItem(new Item("A", "Cat", 10, 15, 3));  // low
        inv.addItem(new Item("B", "Cat", 10, 15, 5));  // boundary
        inv.addItem(new Item("C", "Cat", 10, 15, 6));  // just above
        inv.addItem(new Item("D", "Cat", 10, 15, 20)); // high
    }

    // -------- ECT --------

    @Test
    void ect_negativeThreshold_returnsEmpty() {
        List<Item> result = inv.getLowStockItems(-1);
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    void ect_emptyInventory_returnsEmpty() {
        inv.getItems().clear();
        List<Item> result = inv.getLowStockItems(5);
        assertTrue(result.isEmpty());
    }

    // -------- BVT around threshold 5 --------

    @Test
    void bvt_threshold_justBelowBoundary_includesStock3_only() {
        List<Item> result = inv.getLowStockItems(4); // just below 5
        assertEquals(1, result.size());
        assertEquals("A", result.get(0).getName());
    }

    @Test
    void bvt_threshold_atBoundary_includesStock3_and5() {
        List<Item> result = inv.getLowStockItems(5); // boundary
        assertEquals(2, result.size());
        assertTrue(result.stream().anyMatch(i -> i.getName().equals("A")));
        assertTrue(result.stream().anyMatch(i -> i.getName().equals("B")));
    }

    @Test
    void bvt_threshold_justAboveBoundary_includes3_5_6() {
        List<Item> result = inv.getLowStockItems(6); // just above
        assertEquals(3, result.size());
        assertTrue(result.stream().anyMatch(i -> i.getName().equals("A")));
        assertTrue(result.stream().anyMatch(i -> i.getName().equals("B")));
        assertTrue(result.stream().anyMatch(i -> i.getName().equals("C")));
    }

    @Test
    void ect_largeThreshold_includesAllItems() {
        List<Item> result = inv.getLowStockItems(1000);
        assertEquals(4, result.size());
    }
}
